/** Automatically generated file. DO NOT MODIFY */
package br.com.conecta.lugares;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}